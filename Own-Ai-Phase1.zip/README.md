# OWN AI

Phase 1 foundation for a production-oriented AI creative web application.

## Stack
- Next.js 16.3.3 / React 19
- FastAPI
- SQLAlchemy 2
- PostgreSQL-ready database configuration
- Alembic
- JWT authentication
- Argon2 password hashing

## Run backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
fastapi dev app/main.py
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```

Phase 1 intentionally contains no AI-provider or payment implementation. Those will be added only after this foundation passes verification.
