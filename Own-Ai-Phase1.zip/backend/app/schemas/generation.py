from datetime import datetime
from pydantic import BaseModel

class GenerationOut(BaseModel):
    id: int
    kind: str
    prompt: str | None
    status: str
    output_url: str | None
    credits_used: int
    created_at: datetime
