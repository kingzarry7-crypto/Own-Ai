from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "OWN AI API"
    environment: str = "development"
    secret_key: str = "CHANGE_ME_IN_ENV"
    database_url: str = "sqlite:///./own_ai.db"
    cors_origins: str = "http://localhost:3000"
    access_token_minutes: int = 60
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    @property
    def cors_list(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

settings = Settings()
