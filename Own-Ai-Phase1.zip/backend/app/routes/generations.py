from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..core.database import get_db
from ..core.deps import get_current_user
from ..models.generation import Generation
from ..schemas.generation import GenerationOut

router = APIRouter(prefix="/generations", tags=["generations"])
@router.get("", response_model=list[GenerationOut])
def history(user=Depends(get_current_user), db: Session=Depends(get_db)):
    return list(db.scalars(select(Generation).where(Generation.user_id == user.id).order_by(Generation.created_at.desc()).limit(100)))
