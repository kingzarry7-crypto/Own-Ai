from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..core.database import get_db
from ..core.deps import get_current_admin
from ..models.user import User
from ..models.generation import Generation

router = APIRouter(prefix="/admin", tags=["admin"])
@router.get("/stats")
def stats(user=Depends(get_current_admin), db: Session=Depends(get_db)):
    return {"users": db.scalar(select(func.count()).select_from(User)) or 0, "generations": db.scalar(select(func.count()).select_from(Generation)) or 0}
