from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..core.database import get_db
from ..core.security import create_access_token
from ..schemas.auth import RegisterRequest, LoginRequest, TokenResponse, UserOut
from ..services.auth import register, authenticate
from ..core.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])

def output(user):
    return UserOut(id=user.id, name=user.name, email=user.email, role=user.role, credits=user.credits, is_suspended=user.is_suspended)

@router.post("/register", response_model=TokenResponse, status_code=201)
def register_user(payload: RegisterRequest, db: Session = Depends(get_db)):
    try: user = register(db, payload.name, payload.email, payload.password)
    except ValueError as e: raise HTTPException(409, str(e))
    return TokenResponse(access_token=create_access_token(str(user.id)), user=output(user))

@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = authenticate(db, payload.email, payload.password)
    if not user or user.is_suspended: raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    return TokenResponse(access_token=create_access_token(str(user.id)), user=output(user))

@router.get("/me", response_model=UserOut)
def me(user=Depends(get_current_user)):
    return output(user)
