from sqlalchemy.orm import Session
from ..models.user import User
from ..models.credit_transaction import CreditTransaction

def change_credits(db: Session, user: User, amount: int, kind: str, description: str = "", reference: str | None = None):
    before = user.credits
    after = before + amount
    if after < 0:
        raise ValueError("Insufficient credits")
    user.credits = after
    tx = CreditTransaction(user_id=user.id, type=kind, amount=amount, balance_before=before, balance_after=after, reference=reference, description=description)
    db.add(tx)
    return tx
