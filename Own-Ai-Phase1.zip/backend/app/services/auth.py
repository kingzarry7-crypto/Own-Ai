from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models.user import User
from ..core.security import hash_password, verify_password

def register(db: Session, name: str, email: str, password: str):
    email = email.lower().strip()
    if db.scalar(select(User).where(User.email == email)):
        raise ValueError("Email already registered")
    user = User(name=name.strip(), email=email, password_hash=hash_password(password))
    db.add(user); db.commit(); db.refresh(user)
    return user

def authenticate(db: Session, email: str, password: str):
    user = db.scalar(select(User).where(User.email == email.lower().strip()))
    if not user or not verify_password(password, user.password_hash):
        return None
    return user
