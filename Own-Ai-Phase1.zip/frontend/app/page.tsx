import Link from 'next/link';
export default function Home(){return <main className="wrap"><div className="card"><p className="muted">AI CREATIVE STUDIO</p><h1>OWN AI</h1><p>One workspace for creating, editing and transforming images.</p><Link className="btn" href="/register">Get started</Link></div></main>}
