import './globals.css';
import Link from 'next/link';
export default function RootLayout({children}:{children:React.ReactNode}){return <><nav className="nav"><b>OWN AI</b><Link href="/dashboard">Dashboard</Link><Link href="/studio">Studio</Link><Link href="/history">History</Link><Link href="/admin">Admin</Link></nav>{children}</>}
